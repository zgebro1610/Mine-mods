damage @e[limit=1,distance=..4,type=immersive_aircraft:biplane] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..4,type=immersive_aircraft:airship] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..4,type=immersive_aircraft:cargo_airship] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..4,type=immersive_aircraft:gyrodyne] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..4,type=immersive_aircraft:quadrocopter] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..4,type=immersive_aircraft:warship] 100 minecraft:player_attack by @p
damage @e[limit=1,distance=..5,type=immersive_aircraft:bamboo_hopper] 100 minecraft:player_attack by @p
