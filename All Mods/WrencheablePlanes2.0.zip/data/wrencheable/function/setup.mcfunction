scoreboard objectives add sneaking minecraft.custom:sneak_time


# Remnant code from version Pre 1.2
# scoreboard objectives add ticks dummy
# tellraw @a {"text":"Successfully Installed","color":"green"}
# tellraw @a {"text":"No Restart Needed :)","color":"gold"}