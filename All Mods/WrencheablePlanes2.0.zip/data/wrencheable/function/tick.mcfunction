

execute at @a[scores={sneaking=1..},nbt={SelectedItem:{id:"create:wrench",count:1}}] run function wrencheable:killplane
execute at @a[scores={sneaking=1..},nbt={SelectedItem:{id:"create:wrench",count:1}}] run function mom:killplane